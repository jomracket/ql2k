QL2K : Sinclair QL Emulator for Windows 2000/XP
===============================================

Current version : 0.1 Build 0.96a ( Alpha ).
Changes :
# Additionnal support for multiples ROM files
# Minor bugs corrections.
# Enabling support of speedscreen+ for QL2K registered users.

Previous version : 0.93a ( Alpha ).
Changes :
# Correction of WIN Drives configuration OpenFile DialogBoxes
# Correction of Auto Start parameters ( The setting were not being saved correctly ).

Previous version : 0.92a ( Alpha ).
Changes :
# Added support for Long file names for WINx_ drives.
# Release of English Menu for DirectDraw and Hot configuration support.
# Adding AutoStart option that lets Emulation start automatically after 3 seconds.
This version is supplied as a patch of version 0.91a.


First Version : 0.91a ( Alpha pre-release ).


Contributors :
--------------
	Jan Venema, author of the original QLAY. Please
        read the Original-ReadMe.txt for more information.
	Please note that Jan Venema has NOT been part of QL2K 
        development, so don't solicit him about QL2K.

	Raphael Zhou for part of the DirectX/Windows issues,

	Jimmy Montesinos for part of the DirectX/Windows issues.
        Jimmy is the one to contact regarding QL2K!
	( http://www.jadiam.org/Contact.php )

	Simon N Goodwin for additionnal ROM Supports


REGISTRATION :
--------------

QL2K is now a postcardware or registerware...
Like freeware, we need to know about you in order to continue development
on QL2K and help it not to become AbandonWare.

So please do REGISTER! Fill in the registration form in REGISTER.TXT and send
it by email to : QL2K@Jadiam.org


WARRANTY :
----------
As this software is not commercial, it is provide AS IS and the authors
cannot be held responsible for any damage or data lost caused by the software.
Support is supplied only by email on a best effort basis. Response time may 
be long depending on current work and family issues ;-)


WEBPAGE :
---------

The QL2K webpage is at present located  at :

				http://www.jadiam.org/QL/index.php


FEATURES :
----------
QL2K can handle up to 8 win_ drives and up to 8 emulated mdv_ drives,
QL2K supports full screen display with DirectX,
...


GETTING STARTED :
-----------------

After installing the software with the setup program ( QL2K-Setup.exe ),
all you have to do is launch QL2K.EXE.

- Note on installation in the same directory as QLAY:

If you plan to use QL2K in the same directory as QLAY, please make a backup
of you current QLAY directory before installing QL2K.

As there are some new features, you'll have to restore your MDV and WIN files
or directories.

Note that QLAYT.EXE tool, is the same as that for QLAY 0.90.

As QL2K has a proper QLAY.INI file you can have different configurations to 
those of QLAY.

The QLAY.LOG file is the same for both, so you may encounter problems if you 
try to run more than one instance of QLAY or QL2K at the same time.


Some information on the configuration screen :
------------------------------------------

Memory size ( Taille m�moire ): 
		128 Kb for QL Classic Black Box
		640 Kb for QL + 512 Kb Memory extension
               and so on. ( I normally use 1 MB for most things ).

Screen Size ( Taille �cran ): 
		This setting depends on your Windows resolution setting so
		if your resolution is 640*480, use 512*256 for QL2K.
		if your resolution is 1280*768, use 1024*768 for QL2K.

Keyboard country ( Langue Clavier ): 
		You can select the local Keyboard type for QL Emulation, so if 
		you use a french keyboard select french (default ;)
		Possible choices are : US, UK, FR, GE, IT.

Speed ( Vitesse ):
		Emulation speed control. This controls the number of instructions that 
		should occur between each internal 1 msec 'tick'
		To help you find the right setting for your system, LOAD the 
		mdv1_FT_bas utility and RUN it from inside the QL2K emulator.
		The program will tell you by how much to multiply or divide the
		current value.

Delay ( D�lai ): 
		Emulation delay. Slows the emulator down to contend with eg games that
		go to fast. It is quite difficult to set it correctly.

		       For example on my P3 1 Ghz I set :
		       Speed : 1200
		       Delay : 100

		These settings should give something near the speed of original QL.
		A setting of 0 means no delay.

ROM :
		BOOT : is the main operating system for example : MIVERVA198.ROM
		ROM1 : generally TK2.ROM at 0c000 ( hex )
		ROM2 : generally NFA.ROM at 10000 ( hex )

		If the ROM1 slot is empty please set the NFA.ROM to 10000 ( hex ) in 
		the ROM1 slot.

No mouse ( Pas de souris ): 
		Unchecked by default, I'm still not sure on how to use it properly 
		as I don't have any QL application to test it.

DirectDraw: 
		If checked DirectX support is initiated instead of GDI.

No ALT Key ( Pas de touches ALT ):
		This tick box is checked by default. As AltGr key always emulates the 
		QL Alt key you will not normally need the ALT key under emulation, 
		and this setting allows Windows to interpret ALT shortcuts.

Full screen ( Plein Ecran ) : 
		Only enabled if DirectX is checked.

MDV WIN button: 
		Opens a dialog box to configure the Win and MDV drive locations.

SAVE button:
		This very usefull button is used to save your configuration setting
        in the QLAY.INI file.

CANCEL button: 
		Cancel your last modification settings or cancel execution of QL2K
		if emulation is not yet running,

OK button: 
		Validate any modification to your settings and run the emulation (unless 
		it is already running).


HOW TO QUIT QL2K :
------------------

While the emulator is running you can quit QL2K by hitting the ALT+F4 
keys or, from the menu, by clicking on QL / Quit.
                              

FILES PROVIDED WITH QL2K :
-------------------------

At this time I'm not sure whether it is right to include some of these files 
with QL2K, such as: TK2.ROM, NFA.ROM, MINERVAxxx.ROM and JM.ROM... Please let
me know if this is wrong! Contact me at :

http://www.jadiam.org/Contact.php

QL2K users should make sure they have a licence to use any of these external 
files before use!


KNOWN ISSUES :
-------------

As I'm french, there may be some language issues with parts of the program and
documentation. However, QL2K is designed to work with foreign ROMs.

I can correct problems of this kind if you can describe them to me precisely.
For example :

PC Key : ~ is # on the QL instead of ~

Please let me have exact details of each key, as I don't know any other 
keyboard than the French one.

I am planning for QL2K to support English, French and German. But if you are 
interested in any other language, let me know, and I will see what I can do.


COMPATIBILITY :
---------------

QL2K has been tested on several Windows 2000 machines without problems.
It should work on Windows 98 but has not been tested at this time.
It should work on Windows XP but has not been tested at this time.

Let me know if you encounter any problems on any of these operating systems.

QL2K needs a machine fully compatible with Windows 2000 on Intel architecture,
QL2K needs about 9 Mbytes of free RAM to operate
QL2K needs about 3 Mbytes of free Hard Disk space on your machine
QL2K needs DirectX 8.0 or later.

At present QL2K doesn't emulate QL sound.


PERFORMANCE :
--------------

Native 68k
System/CPU		print  function	string	Configuration/Emulator
QL original		  980	  840	 1100	128k, JS-ROM
SandyQL			 1080	 1040	 1360	512k, Floppy, Par. Port
GoldCard		 2580	 4280	 5680
Super GoldCard	 5680	10260	13820
Amiga 68040/25	 9480	16540	23000	AmigaQDOS (JS/3.24)
QXL-20			14300	27900	70640
Amiga 68060/50	10480	48750	73880	AmigaQdos 3.24 Beta (Blitter)

Emulated 68k
System/CPU		print  function	string	Configuration/Emulator
486/DX2-66		  660	  980	 1300	QLAY081 -d2 (DOS)
486/DX2-66		 1080	 1360	 1820	QLAY082	-d2 (DOS)
486/DX2-66		  920	 1440	 1840	QLAY083 -d2 (Linux)
Amiga A1200		 2500	 1800	 2000	QL emulator, with 68060/50MHz
Pentium/150		 2360	 3680	 4960	QLAY082
PentiumPro/200	 6000	 8000	11000	QLAY082 -f2900
Pentium/200		 5260	 9340	12660	QLAYW087 size 1, 16k colors
Pentium/150		 7120	10840	28120	QPC



QL2K :( P = Pentium, DX = DirectX )
System/CPU		print  function	string	Configuration/Emulator
P III/1Ghz/GDI 		27920	49460	65740	QL2K -f15000, Minerva 1.98, 1MB RAM
P III/1Ghz/DX 		29240	48500	65280	QL2K -f15000, Minerva 1.98, 1MB RAM 
										

Same system with QPC2 :
P III/1Ghz/DX 		33040	93620	221680	QPC2 SMSQ


OTHER NOTES :
--------------

Please, help me keep this product alive! If you have any requests, 
recommendations, or whatever, let me know by email at :

				http://www.jadiam.org/Contact.php

You can write to me in english, french or spanish. If you see any errors in 
this file please help me to correct them too.


Thanks for reading this readme file,

Jimmy MONTESINOS.
http://www.jadiam.org/Contact.php

